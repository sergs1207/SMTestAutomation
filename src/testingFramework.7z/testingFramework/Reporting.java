package testingFramework;

public class Reporting {

	public void generateHTMLreport() {
		// TODO Auto-generated method stub
		
	}



}
