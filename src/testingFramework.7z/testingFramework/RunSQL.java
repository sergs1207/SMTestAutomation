package testingFramework;

public class RunSQL {

	private String query;

public RunSQL (String query){
	this.query = query;
}

public String getResultToString() {
    String convertedResult;
	return "";
	
}

	
}
