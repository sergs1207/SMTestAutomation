package testingFramework;

public class EnvironmentSetup {




	public void getIniFile(String pathToIni) {
		// TODO Auto-generated method stub
		
	}

	public void CreateDbTablesWithData() {
		// TODO Auto-generated method stub
		
	}

}
